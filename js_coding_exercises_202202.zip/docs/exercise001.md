# Exercises 001

This first set of challenges focus on the following skills:

- Working with primitive data types (strings, numbers, booleans, null, undefined)
- Operators
- Functions
- Working with complex data types (objects, arrays)
- Conditional logic (if statements, switch statements)
- Looping over arrays

Make sure to add and commit every time you get something working!

Push up to Github too, so we can see how you're getting on 😊

Once you have completed this first set of challenges you can move onto the next ones: [Exercises 002 - Docs](./exercise002.md)
